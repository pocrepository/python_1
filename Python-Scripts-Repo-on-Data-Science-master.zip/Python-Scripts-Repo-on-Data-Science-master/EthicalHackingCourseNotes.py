# -*- coding: utf-8 -*-
"""
Created on Thu Jun 15 16:03:49 2017

@author: Shabaka
"""

# Pen test methodology
# 1. Vulnerability
# 2. Exploit - End of Pen Testing
# 3. Trace Removal
##########################################################
# elevate privileges 
# copy or move data
# log out without being noticed

#####################################################
# Attack Vectors
# 3 major areas
# Network -
# Host OS aatack /
# Application attacks
######################################################
# Vulnerability Managment
# 6 steps
# discover 
# cat and priorotise
# scan for vul
# report and classify
# remediate
# verify checks
##############################
# Incident Management - Quickly resolve incidents with min
# impact to the process or business
# Improve monitoring
# elimination of loss of requests
# availability of info
# accurate CMDB infor
# improve user and cust satisfaction
#########################
# Incident Management Plan
# Identify
# Analyse
# Gather infor
# Contain
# Mitigate
# Eradicate
######################################################
# Risk Assesment
#  Vulnerability Assessments
  
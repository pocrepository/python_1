# -*- coding: utf-8 -*-
"""
Created on Tue Mar 28 23:30:21 2017

@author: Shabaka
"""
import pandas as pd

# Extract the created_at column from df: tweet_time
tweet_time = df['created_at']

# Extract the clock time: tweet_clock_time
tweet_clock_time = [entry[11:19] for entry in tweet_time]

# Print the extracted times
print(tweet_clock_time)


# '''''''''''''''' Conditional List Comprehension - Time Stamped Data ' #

# Extract the created_at column from df: tweet_time
tweet_time = df['created_at']

# Extract the clock time: tweet_clock_time
tweet_clock_time = [entry[11:19] for entry in tweet_time if entry[17:19] == '19']

# Print the extracted times
print(tweet_clock_time)
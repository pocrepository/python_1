# -*- coding: utf-8 -*-
"""
Created on Tue May 16 17:04:55 2017

@author: Shabaka
"""
import numpy as np
import pandas as pd

from bokeh.plotting import figure
from bokeh.io import output_file, show
from bokeh.plotting import ColumnDataSource
from bokeh.models import HoverTool 

# Create the figure: p
p = figure(x_axis_label='fertility (children per woman)',
           y_axis_label='female_literacy (% population)')

# Add a circle glyph to the figure p
p.circle(fertility, female_literacy)

# Call the output_file() function and specify the name of the file
output_file('fert_lit.html')

# Display the plot
show(p)

# ''''''''''''' Multiple Dta plots ''''''#

# Create the figure: p
p = figure(x_axis_label='fertility',
           y_axis_label='female_literacy (% population)')

# Add a circle glyph to the figure p
_ = p.circle(fertility_latinamerica, female_literacy_latinamerica)

# Add an x glyph to the figure p
_ = p.x(fertility_africa, female_literacy_africa)

# Specify the name of the file
output_file('fert_lit_separate.html')

# Display the plot
show(p)

# '''''Scatter Plot Customisation '''''''#

# Create the figure: p
p = figure(x_axis_label='fertility (children per woman)',
           y_axis_label='female_literacy (% population)')

# Add a blue circle glyph to the figure p
p.circle(fertility_latinamerica, female_literacy_latinamerica,
         color='blue', size=10, alpha=0.8)

# Add a red circle glyph to the figure p
p.circle(fertility_africa, female_literacy_africa,
         color='red', size=10, alpha=0.8)

# Specify the name of the file
output_file('fert_lit_separate_colors.html')

# Display the plot
show(p)


# ''''Bokeh Line PLot '''''''''''#

# Import figure from bokeh.plotting - to p of file

# Create a figure with x_axis_type="datetime": p
p = figure(x_axis_type='datetime',
           x_axis_label='Date', y_axis_label='US Dollars')

# Plot date along the x axis and price along the y axis
p.line(date, price, line_width=3)

# Specify the name of the output file and show the result
output_file('line.html')
show(p)

# '''''Line and Marker Plot ''''''''#

# Import figure from bokeh.plotting - top of file

# Create a figure with x_axis_type='datetime': p
p = figure(x_axis_type='datetime', x_axis_label='Date',
           y_axis_label='US Dollars')

# Plot date along the x-axis and price along the y-axis
p.line(date, price)

# With date on the x-axis and price on the y-axis,
# add a white circle glyph of size 4
p.circle(date, price, fill_color='white', size=4)

# Specify the name of the output file and show the result
output_file('line.html')
show(p)

# ''''''Bokeh Patch Plots 'Maps' ''#

# Create a list of az_lons, co_lons, nm_lons and ut_lons: x
x = [az_lons, co_lons, nm_lons, ut_lons]

# Create a list of az_lats, co_lats, nm_lats and ut_lats: y
y = [az_lats, co_lats, nm_lats, ut_lats]

# Add patches to figure p with line_color=white for x and y
p.patches(x, y, line_color='white')

# Specify the name of the output file and show the result
output_file('four_corners.html')
show(p)


# ''''''''' Plotting from a numpy array ''''''#

# Import numpy as np - at top of file

# Create array using np.linspace: x
x = np.linspace(0, 5, 100)

# Create array using np.cos: y
y = np.cos(x)

# Add circles at x and y
p.circle(x, y)

# Specify the name of the output file and show the result
output_file('numpy.html')
show(p)

# '''''''' Plotting from Pandas Dataframe ''''''''#

# Import pandas as pd - top of file

# Read in the CSV file: df
df = pd.read_csv('auto.csv')

# Import figure from bokeh.plotting - top of file

# Create the figure: p
p = figure(x_axis_label='HP', y_axis_label='MPG')

# Plot mpg vs hp by color
p.circle(df['hp'], df['mpg'], color=df['color'], size=10)

# Specify the name of the output file and show the result
output_file('auto-df.html')
show(p)

# '''''''' Plot from ColumnData Source ''''''''#

# Import the ColumnDataSource class from bokeh.plotting

# Create a ColumnDataSource from df: source
source = ColumnDataSource(df)

# Add circle glyphs to the figure p
p.circle('Year', 'Time', source=source, color='color', size=8)

# Specify the name of the output file and show the result
output_file('sprint.html')
show(p)

# '''''''Selection and non-Selection Glyph Specification ''''#

# Create a figure with the "box_select" tool: p
p = figure(x_axis_label='Year', y_axis_label='Time', tools='box_select')

# Add circle glyphs to the figure p with the selected
# and non-selected properties

p.circle('Year', 'Time', source=source,
         selection_color='red', nonselection_alpha=0.1)

# Specify the name of the output file and show the result
output_file('selection_glyph.html')
show(p)

# ''''''making Hover Glyphs '''''''#

# import the HoverTool - at top of file

# Add circle glyphs to figure p
p.circle(x, y, size=10,
         fill_color='grey', alpha=0.1, line_color=None,
         hover_fill_color='firebrick', hover_alpha=0.5,
         hover_line_color='white')

# Create a HoverTool: hover
hover = HoverTool(tooltips=None, mode='vline')

# Add the hover tool to the figure p
p.add_tools(hover)

# Specify the name of the output file and show the result
output_file('hover_glyph.html')
show(p)

# ''''''''' Color Mapping '''''''''''#

#Import CategoricalColorMapper from bokeh.models
from bokeh.models import CategoricalColorMapper

# Convert df to a ColumnDataSource: source
source = ColumnDataSource(df)

# Make a CategoricalColorMapper object: color_mapper
color_mapper = CategoricalColorMapper(factors=['Europe', 'Asia', 'US'],
                                      palette=['red', 'green', 'blue'])

# Add a circle glyph to the figure p
p.circle('weight', 'mpg', source=source,
            color=dict(field='origin', transform=color_mapper),
            legend='origin')

# Specify the name of the output file and show the result
output_file('colormap.html')
show(p)
